const sqlite3 = require('sqlite3').verbose();

// Initialize a new database object
let db = new sqlite3.Database('./emails.db', (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the database.');
});

// Function to get data from your table
db.getData = function(callback) {
  db.all("SELECT * FROM messages", function(err, rows) {
    if(err) {
      return callback(err);
    }
    callback(null, rows);
  });
};

// Function to get data from your projects table
db.getProjects = function(callback) {
  db.all("SELECT * FROM projects", function(err, rows) {
    if(err) {
      return callback(err);
    }
    callback(null, rows);
  });
};

module.exports = db;
