const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const db = require('./db.js');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const corsOptions = {
	origin: 'http://localhost:3000',
	methods: ['GET', 'POST', 'DELETE', 'PUT'],
	allowedHeaders: ['Content-Type'],
};

app.use(cors(corsOptions));

const server = http.createServer(app);

// Pass the same cors configuration to the socket.io server
const io = socketIo(server, {
	cors: corsOptions,
});

io.on('connection', (socket) => {
	console.log('New client connected');

	setInterval(() => {
		db.all(
			` SELECT *
      FROM (
          SELECT *,
                 ROW_NUMBER() OVER (PARTITION BY company ORDER BY idmessages DESC) as message_rank
          FROM messages
		  WHERE message_body IS NOT NULL AND message_body <> ''
      ) WHERE message_rank <= 2;
	  
	`,
			[],
			(err, rows) => {
				if (err) {
					throw err;
				}
				socket.emit('NewData', rows);
			}
		);
	}, 2000);

	// New setInterval function to send projects data
	setInterval(() => {
		db.getProjects((err, rows) => {
			if (err) {
				throw err;
			}

			socket.emit('NewProjectData', rows);
		});
	}, 2000);

	socket.on('disconnect', () => console.log('Client disconnected'));
});

app.delete('/message/:id', (req, res) => {
	const { id } = req.params;
	db.all(` DELETE FROM messages WHERE idmessages=${id}`, (err, rows) => {
		if (rows.length < 1) {
			res.status(200).json({
				success: true,
				message: 'Deleted successfully',
			});
		}
		if (err) {
			res.status(500).json({
				success: false,
				message: err,
			});
		}
	});
});
app.put('/message/:id', (req, res) => {
	const { id } = req.params;
	const { priority } = req.body;
	db.all(
		` UPDATE messages SET priority = ${priority} WHERE idmessages=${id}`,
		(err, rows) => {
			if (rows.length < 1) {
				res.status(200).json({
					success: true,
					message: 'Priority set successfully',
				});
			}
			if (err) {
				res.status(500).json({
					success: false,
					message: err,
				});
			}
		}
	);
});
const port = process.env.PORT || 4001;
server.listen(port, () => console.log(`Listening on port ${port}`));
