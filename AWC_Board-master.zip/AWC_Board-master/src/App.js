import React from 'react';
import './App.css';
import { useState } from 'react';
import {
	BadgeDelta,
	Card,
	Grid,
	Tab,
	TabList,
	Text,
	Title,
	Flex,
	Metric,
	DeltaType,
	ProgressBar,
	AreaChart,
	Toggle,
	ToggleItem,
	Icon,
} from '@tremor/react';
import { InformationCircleIcon } from '@heroicons/react/outline';
import { useNavigate } from 'react-router-dom';
import { MailIcon } from '@heroicons/react/solid';

type Kpi = {
	title: string,
	metric: string,
	progress: number,
	target: string,
	delta: string,
	deltaType: DeltaType,
};

const kpiData: Kpi[] = [
	{
		title: 'Sales',
		metric: '$ 12,699',
		progress: 15.9,
		target: '$ 80,000',
		delta: '13.2%',
		deltaType: 'moderateIncrease',
	},
	{
		title: 'Profit',
		metric: '$ 45,564',
		progress: 36.5,
		target: '$ 125,000',
		delta: '23.9%',
		deltaType: 'increase',
	},
	{
		title: 'Customers',
		metric: '1,072',
		progress: 53.6,
		target: '2,000',
		delta: '10.1%',
		deltaType: 'moderateDecrease',
	},
];

const performance = [
	{
		date: '2021-01-01',
		Sales: 900.73,
		Profit: 173,
		Customers: 73,
	},
	{
		date: '2021-01-02',
		Sales: 1000.74,
		Profit: 174.6,
		Customers: 74,
	},
	{
		date: '2021-03-13',
		Sales: 882,
		Profit: 682,
		Customers: 682,
	},
];

const dollarFormatter = (value: number) =>
	`$ ${Intl.NumberFormat('us').format(value).toString()}`;

const numberFormatter = (value: number) =>
	`${Intl.NumberFormat('us').format(value).toString()}`;

export default function App() {
	const navigate = useNavigate();
	const [selectedView, setSelectedView] = useState('1');
	const [selectedKpi, setSelectedKpi] = useState('Sales');

	const formatters = {
		Sales: dollarFormatter,
		Profit: dollarFormatter,
		Customers: numberFormatter,
	};

	return (
		<main className='bg-slate-50 p-6 sm:p-10'>
			<Title>Winning</Title>

			<TabList
				defaultValue='1'
				onValueChange={(value) => setSelectedView(value)}
				className='mt-6'
			>
				<Tab value='1' text='Overview' />
				<Tab value='2' text='Detail' />
			</TabList>

			{selectedView === '1' ? (
				<>
					<Grid numColsLg={3} className='mt-6 gap-6'>
						{kpiData.map((item, index) => (
							<Card
								key={item.title}
								className={index === 0 ? 'orange-card' : ''}
							>
								<Flex alignItems='start'>
									<div className='truncate'>
										<Text>{item.title}</Text>
										<Metric className='truncate'>{item.metric}</Metric>
									</div>
									{index === 0 && (
										<Icon
											size='md'
											icon={MailIcon}
											tooltip='First card mail icon'
										/>
									)}
									<BadgeDelta deltaType={item.deltaType}>
										{item.delta}
									</BadgeDelta>
								</Flex>
								<Flex className='mt-4 space-x-2'>
									<Text className='truncate'>{`${item.progress}% (${item.metric})`}</Text>
									<Text>{item.target}</Text>
								</Flex>
								<ProgressBar percentageValue={item.progress} className='mt-2' />
							</Card>
						))}
					</Grid>

					<Grid numColsLg={3} className='mt-6 gap-6'>
						{kpiData.map((item, index) => (
							<Card key={index + item.title}>
								<Flex alignItems='start'>
									<div className='truncate'>
										<Text>{item.title}</Text>
										<Metric className='truncate'>{item.metric}</Metric>
									</div>
									<BadgeDelta deltaType={item.deltaType}>
										{item.delta}
									</BadgeDelta>
								</Flex>
								<Flex className='mt-4 space-x-2'>
									<Text className='truncate'>{`${item.progress}% (${item.metric})`}</Text>
									<Text>{item.target}</Text>
								</Flex>
								<ProgressBar percentageValue={item.progress} className='mt-2' />
							</Card>
						))}
					</Grid>

					<Card className='mt-6'>
						<div className='md:flex justify-between'>
							<div>
								<Flex
									justifyContent='start'
									className='space-x-0.5'
									alignItems='center'
								>
									<Title> Performance History </Title>
									<Icon
										icon={InformationCircleIcon}
										variant='simple'
										tooltip='Shows day-over-day (%) changes of past performance'
									/>
								</Flex>
								<Text> Daily increase or decrease per domain </Text>
							</div>
							<div className='mt-6 md:mt-0'>
								<Toggle
									color='zinc'
									defaultValue={selectedKpi}
									onValueChange={(value) => setSelectedKpi(value)}
								>
									<ToggleItem value='Sales' text='Sales' />
									<ToggleItem value='Profit' text='Profit' />
									<ToggleItem value='Customers' text='Customers' />
								</Toggle>
							</div>
						</div>
						<AreaChart
							data={performance}
							index='date'
							categories={[selectedKpi]}
							colors={['blue']}
							showLegend={false}
							valueFormatter={formatters[selectedKpi]}
							yAxisWidth={56}
							className='h-96 mt-8'
						/>
					</Card>
				</>
			) : (
				<Card className='mt-6'>
					<div className='h-96' />
				</Card>
			)}
		</main>
	);
}
