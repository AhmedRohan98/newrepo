import React, { useEffect, useState } from 'react';
import ApiRequest from './axiosInterceptor';
import './App.css';
import socketIOClient from 'socket.io-client';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
	Badge,
	Card,
	Flex,
	Text,
	Legend,
	TextInput,
	Button,
	Callout,
	BadgeDelta,
	Icon,
	Grid,
	List,
	ListItem,
	Title,
	Bold,
	Color,
} from '@tremor/react';
import {
	Accordion,
	AccordionHeader,
	AccordionBody,
	AccordionList,
} from '@tremor/react';
import {
	MailIcon,
	SparklesIcon,
	BriefcaseIcon,
	DesktopComputerIcon,
	ShieldExclamationIcon,
	ShoppingBagIcon,
	ArrowNarrowRightIcon,
	LightningBoltIcon,
	HomeIcon,
	TrashIcon,
	TruckIcon,
} from '@heroicons/react/solid';
import { FlagIcon } from '@heroicons/react/outline';
import { logDOM } from '@testing-library/react';
const ENDPOINT = 'http://localhost:4001';
const DynamicCardList = () => {
	const [data, setData] = useState([]);
	const [firstCard, setFirstCard] = useState(null);
	const [secondCard, setSecondCard] = useState(null);
	const [thirdCard, setThirdCard] = useState(null);
	const [fourthCard, setFourthCard] = useState(null);
	const [fifthCard, setFifthCard] = useState(null);
	const [sixthCard, setSixthCard] = useState(null);
	const [championCard, setChampionCard] = useState(null);
	const [othersCard, setOthersCard] = useState(null);
	const [socket, setSocket] = useState(null);
	const [form, setForm] = useState({ title: '', content: '' });
	const [clicks, setClicks] = useState(1);
	const [mailIcons, setMailIcons] = useState([0]);
	const [projects, setProjects] = useState([]);
	const handleInputChange = (e) => {
		setForm({ ...form, [e.target.name]: e.target.value });
	};
	const handleFormSubmit = (e) => {
		e.preventDefault();
		setForm({ title: '', content: '' });
	};
	const handleButtonClick = () => {
		setClicks(clicks + 1);
		setMailIcons([...mailIcons, clicks]);
	};
	// define the titles of the predefined cards
	const predefinedCardTitles = [
		'Dynamis',
		'CAM-SLB',
		'HMH',
		'EnQuest',
		'Evolution',
		'Quadvest',
		'Champion',
	];
	const basicColors = [
		'blue',
		'red',
		'green',
		'yellow',
		'orange',
		'purple',
		'pink',
		'teal',
		'brown',
		'gray',
	];
	// New state variable for the new card data
	const [newCardData, setNewCardData] = useState([
		{
			name: 'New Card',
			data: [
				{
					name: 'Sample Data',
					icon: SparklesIcon,
					color: 'pink',
					numTransactions: 5,
					amount: '$ 500',
				},
				// Add more data as needed
			],
		},
		// Add more cards as needed
	]);
	useEffect(() => {
		const newSocket = socketIOClient(ENDPOINT);
		setSocket(newSocket);
		newSocket.on('NewData', (newdata) => {
			if (newdata[0]) newdata[0].title = 'Dynamis';
			if (newdata[1]) newdata[1].title = 'CAM-SLB';
			if (newdata[2]) newdata[2].title = 'HMH';
			if (newdata[3]) newdata[3].title = 'EnQuest';
			if (newdata[4]) newdata[4].title = 'Evolution';
			if (newdata[5]) newdata[5].title = 'Quadvest';
			if (newdata[6]) newdata[6].title = 'Champion';
			setFirstCard(newdata[0]);
			setSecondCard(newdata[1]);
			setThirdCard(newdata[2]);
			setFourthCard(newdata[3]);
			setFifthCard(newdata[4]);
			setSixthCard(newdata[5]);
			setChampionCard(newdata[6]); // Set the new Champion card
			setData(newdata.slice(7));
			// filter all data that doesn't belong to the predefined cards
			const othersData = newdata
				.slice(7)
				.filter((item) => !predefinedCardTitles.includes(item.company));
			// create an "Others" card
			const othersCard = {
				title: 'Others',
				messages: othersData.map((item) => item.message_body),
				// add any other properties needed for the card
			};
			setOthersCard(othersCard);
		});
		newSocket.on('NewProjectData', (newProjectsData) => {
			setProjects(newProjectsData);
		});
		return () => {
			newSocket.close();
		};
	}, [setSocket]);
	const handleDeleteMessage = (id) => {
		ApiRequest.delete(`/message/${id}`)
			.then((response) => {
				const { data } = response;
				const { success } = data;
				if (data) {
					if (success) {
						toast.success('Deleted successfully');
					} else {
						toast.error('Something went worng');
					}
				}
			})
			.catch((err) => {
				console.log('err', err);
				toast.error('Something went worng ' + err);
			});
	};
	const handlePriority = (id, priorityVal) => {
		console.log(id, priorityVal, 'beenish');
		const data = { priority: priorityVal === 0 ? 1 : 0 };
		ApiRequest.put(`/message/${id}`, data)
			.then((response) => {
				const { data } = response;
				const { success, message } = data;
				if (data) {
					if (success) {
						toast.success(message);
					} else {
						toast.error('Something went worng');
					}
				}
			})
			.catch((err) => {
				console.log('err', err);
				toast.error('Something went worng ' + err);
			});
	};
	// New function to render the new card
	const renderNewCard = (cardData) => (
		<Card key={cardData.name}>
			<Title>Transaction Volume</Title>
			<Text>{cardData.name}</Text>
			<List className='mt-4'>
				{cardData.data.map((transaction) => (
					<ListItem key={transaction.name}>
						<Flex justifyContent='start' className='truncate space-x-4'>
							<Icon
								variant='light'
								icon={transaction.icon}
								size='md'
								color={transaction.color}
							/>
							<div className='truncate'>
								<Text className='truncate'>
									<Bold>{transaction.name}</Bold>
								</Text>
								<Text className='truncate'>
									{`${transaction.numTransactions} transactions`}
								</Text>
							</div>
						</Flex>
						<Text>{transaction.amount}</Text>
					</ListItem>
				))}
			</List>
			<Button
				size='sm'
				variant='light'
				icon={ArrowNarrowRightIcon}
				iconPosition='right'
				className='mt-4'
			>
				View details
			</Button>
		</Card>
	);
	// function to render a card
	const renderCard = (cardData, colorIndex) => (
		//<Card className="orange-card">
		<Card
			className='max-w-xs mx-auto'
			decoration='top'
			decorationColor={basicColors[colorIndex]}
			style={{ boxShadow: '0px 10px 24px rgba(0, 0, 0, 0.1)' }}
		>
			<Flex alignItems='start'>
				<div className='truncate'>
					<h2>{cardData.title}</h2>
				</div>
				<BadgeDelta deltaType={cardData?.deltaType}>
					{cardData?.delta}
				</BadgeDelta>
			</Flex>
			<hr
				style={{
					margin: '15px 0 15px 0',
				}}
			/>

			{/* New code to render badges for matching projects */}
			{projects
				.filter((project) => project.customer === cardData.title)
				.map((project, index, array) => {
					const color = basicColors[index % basicColors.length];
					return (
						<>
							{mailIcons.map((item, index) => (
								<Icon
									key={index}
									size='md'
									icon={MailIcon}
									color={color}
									tooltip={`Mail icon ${index}`}
								/>
							))}
							<Badge
								key={index}
								style={{
									backgroundColor: color,
									color: 'white',
									marginRight: index < array.length - 1 ? '5px' : '0px',
									marginBottom: index === array.length - 1 ? '5px' : '0px',
								}}
							>
								{project.project}
							</Badge>
							{/* <Legend
								className='mt-3'
								categories={data
									.filter((item) => item.company === cardData.title)
									.map((item) => (
										<p>
											<span
												onClick={() => {
													deleteMessage(item?.idmessages);
												}}
											>
												D
											</span>
											&nbsp; {item.message_body}&nbsp; <span>P</span>
										</p>
									))}
								colors={Array(data.length).fill(color)}
							/> */}
							<br />
							<ul>
								{data
									.filter((item) => item.company === cardData.title)
									.map((item, index) => (
										<div className='messages' key={index}>
											<Icon
												key={index}
												size='md'
												icon={TrashIcon}
												color={'red'}
												tooltip={`Delete`}
												onClick={() => {
													handleDeleteMessage(item?.idmessages);
												}}
											/>
											<span style={{ fontSize: '14px', color: '#8b8585' }}>
												{item.message_body.length > 15
													? item.message_body.substring(0, 25) + '...'
													: item.message_body}
											</span>
											{console.log('beenish', item.priority)}
											<Icon
												key={index}
												size='md'
												icon={FlagIcon}
												color={item.priority > 0 ? 'red' : 'blue'}
												tooltip={`Priority`}
												onClick={() => {
													handlePriority(item?.idmessages, item.priority);
												}}
											/>
										</div>
									))}
							</ul>
							<br />
						</>
					);
				})}
			{cardData.title === 'Others'
				? projects
						.filter(
							(project) => !predefinedCardTitles.includes(project.customer)
						)
						.map((project, index, array) => {
							const color = basicColors[index % basicColors.length];
							return (
								<div key={index}>
									<Badge
										key={index}
										style={{
											backgroundColor: color,
											color: 'white',
											marginRight: index < array.length - 1 ? '5px' : '0px',
											marginBottom: index === array.length - 1 ? '5px' : '0px',
										}}
									>
										{project.project}
									</Badge>
									<Legend
										className='mt-3'
										categories={data
											.filter(
												(item) =>
													!predefinedCardTitles.includes(item.company) &&
													item.message_body.length > 0
											)
											.map((item) => item.message_body)}
										colors={Array(data.length).fill(color)}
									/>
								</div>
							);
						})
				: ''}
			{/* Replace AccordionList with Legend */}
		</Card>
	);

	return (
		<div>
			<ToastContainer
				position='top-right'
				autoClose={5000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
				theme='light'
			/>
			<Button onClick={handleButtonClick}>Click Me</Button>
			<Text>{clicks}</Text>
			<h2>Dynamic Cards</h2>
			<Grid numColsLg={5} className='mt-6 gap-6'>
				{newCardData.map((item) => renderNewCard(item))}
				{firstCard && renderCard(firstCard, 0)}
				{secondCard && renderCard(secondCard, 1)}
				{thirdCard && renderCard(thirdCard, 2)}
				{fourthCard && renderCard(fourthCard, 3)}
				{fifthCard && renderCard(fifthCard, 4)}
				{sixthCard && renderCard(sixthCard, 5)}
				{championCard && renderCard(championCard, 6)}
				{othersCard && renderCard(othersCard, 7)}
			</Grid>
			<form onSubmit={handleFormSubmit}>
				<TextInput
					name='title'
					placeholder='Title'
					value={form.title}
					onChange={handleInputChange}
				/>
				<TextInput
					name='content'
					placeholder='Content'
					value={form.content}
					onChange={handleInputChange}
				/>
				<Button type='submit'>Add Card</Button>
			</form>
		</div>
	);
};
export default DynamicCardList;
