import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import App from './App'; 
import TestPage from './TestPage'; 
import { Button } from '@tremor/react';
import { useNavigate } from 'react-router-dom';

const NavigateButton = () => {
  const navigate = useNavigate();
  return <Button onClick={() => navigate('/test')}>Go to Test Page</Button>
}

const MainApp = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<><App /><NavigateButton /></>} /> 
        <Route path="/test" element={<TestPage />} /> 
      </Routes>
    </Router>
  );
};

export default MainApp;
