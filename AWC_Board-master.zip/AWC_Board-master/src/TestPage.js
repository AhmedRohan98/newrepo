import React from 'react';
import DynamicCardList from './DynamicCardList'; // This is a default import
import { Button } from '@tremor/react';
import { useNavigate } from 'react-router-dom';

const TestPage = () => {
  const navigate = useNavigate();

  return (
    <div>
      <Button onClick={() => navigate('/')}>Go back to Dashboard</Button>
      <DynamicCardList />
    </div>
  );
};

export default TestPage; // This is a default export
