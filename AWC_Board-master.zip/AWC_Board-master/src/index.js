import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import MainApp from './MainApp'; // This is a default import
import reportWebVitals from './reportWebVitals';

ReactDOM.createRoot(document.getElementById('root')).render(<MainApp />);

reportWebVitals();

